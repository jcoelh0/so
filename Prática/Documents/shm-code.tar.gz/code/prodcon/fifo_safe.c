/*
 *  @brief A simple FIFO, whose elements are pairs of integers,
 *      one being the id of the producer and the other the value produced
 *
 * @remarks safe, non busy waiting version
 *
 *  The following operations are defined:
 *     \li insertion of a value
 *     \li retrieval of a value.
 *
 * \author (2016) Artur Pereira <artur at ua.pt>
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <errno.h>
#include <sys/shm.h>
#include <sys/sem.h>

#include "fifo.h"
#include "delays.h"

/** \brief internal storage size of <em>FIFO memory</em> */
#define  FIFOSZ         5

/** \brief resource key */
const long key = 0x1111L;

/*
 *  \brief Shared data structure.
 */
typedef struct
{ 
    int semid;         ///< syncronization semaphore
    unsigned int ii;   ///< point of insertion
    unsigned int ri;   ///< point of retireval
    unsigned int cnt;  ///< number of items stored
    struct 
    {
        unsigned int id;     ///< id of the producer
        unsigned int value;  ///< value stored
    } mem[FIFOSZ];           ///< storage memory
} FIFO;

/** \brief internal storage region of FIFO type */
static int shmid = -1;
static FIFO * fifo = NULL;

/* index of access, full and empty semaphores */
#define ACCESS 0
#define FULLNESS 1
#define EMPTINESS 2

/* ************************************************* */

void down(int index)
{
    struct sembuf op = {index, -1, 0};
    if (semop(fifo->semid, &op, 1) == -1)
    {
        perror("down");
        exit(EXIT_FAILURE);
    }
}

/* ************************************************* */

void up(int index)
{
    struct sembuf op = {index, 1, 0};
    if (semop(fifo->semid, &op, 1) == -1)
    {
        perror("up");
        exit(EXIT_FAILURE);
    }
}

/* ************************************************* */

/* Initialization of the FIFO */
void fifoCreate(void)
{
    /* create the shared memory */
    shmid = shmget(key, sizeof(FIFO), 0600 | IPC_CREAT | IPC_EXCL);
    if (shmid == -1)
    {
        perror("Fail creating shared data");
        exit(EXIT_FAILURE);
    }

    /*  attach shared memory to process addressing space */
    fifo = shmat(shmid, NULL, 0);
    if (fifo == (void*)-1)
    {
        perror("Fail connecting to shared data");
        exit(EXIT_FAILURE);
    }

    /* init fifo */
    unsigned int i;
    for (i = 0; i < FIFOSZ; i++)
    {
        fifo->mem[i].id = 99999999;
        fifo->mem[i].value = 99999999;
    }
    fifo->ii = fifo->ri = 0;
    fifo->cnt = 0;

    /* create access, full and empty semaphores */
    fifo->semid = semget(key, 3, 0600 | IPC_CREAT | IPC_EXCL);
    if (fifo->semid == -1)
    {
        perror("Fail creating locker semaphore");
        exit(EXIT_FAILURE);
    }

    /* init semaphores */
    for (i = 0; i < FIFOSZ; i++)
    {
        up(EMPTINESS);
    }
    up(ACCESS);
}

/* ************************************************* */

void fifoConnect()
{
    /* get access to the shared memory */
    shmid = shmget(key, 0, 0);
    if (shmid == -1)
    {
        perror("Fail connecting to shared data");
        exit(EXIT_FAILURE);
    }

    /* attach shared memory to process addressing space */ 
    fifo = shmat(shmid, NULL, 0);
    if (fifo == (void*)-1)
    {
        perror("Fail connecting to shared data");
        exit(EXIT_FAILURE);
    }
}

/* ************************************************* */

void fifoDisconnect()
{
    /* detach shared memory from process addressing space */
    shmdt(fifo);
    fifo = NULL;
    shmid = -1;
}

/* ************************************************* */

void fifoDestroy()
{
    /* destroy semaphore set */
    semctl(fifo->semid, 0, IPC_RMID, NULL);

    /* detach shared memory from process addressing space */
    shmdt(fifo);
    fifo = NULL;

    /* ask OS to destroy the shared memory */
    shmctl(shmid, IPC_RMID, NULL);
    shmid = -1;
}

/* ************************************************* */

/* Insertion of a pait <id, value> into the FIFO  */
void fifoIn(unsigned int id, unsigned int value)
{
    /* decrement emptiness, blocking if full */
    down(EMPTINESS);

    /* lock access */
    down(ACCESS);

    /* Insert pair */
    fifo->mem[fifo->ii].value = value;
    bwDelay(1000);
    fifo->mem[fifo->ii].id = id;
    fifo->ii = (fifo->ii + 1) % FIFOSZ;
    fifo->cnt++;

    /* unlock access and increment fullness */
    up(ACCESS);
    up(FULLNESS);
}

/* ************************************************* */

/* Retrieval of a pair <id, value> from the FIFO */

void fifoOut (unsigned int * idp, unsigned int * valuep)
{
    /* decrement fullness, blocking if full */
    down(FULLNESS);

    /* lock access */
    down(ACCESS);

    /* Retrieve pair */
    *valuep = fifo->mem[fifo->ri].value;
    fifo->mem[fifo->ri].value = 99999999;
    *idp = fifo->mem[fifo->ri].id;
    fifo->mem[fifo->ri].id = 99999999;
    fifo->ri = (fifo->ri + 1) % FIFOSZ;
    fifo->cnt--;

    /* unlock access and increment fullness */
    up(ACCESS);
    up(EMPTINESS);
}

/* ************************************************* */

